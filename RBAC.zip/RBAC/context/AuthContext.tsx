
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { User, Role, AuthContextType } from '../types';
import { MOCK_USERS } from '../services/mockApi';

export const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // In a real app, you'd verify a token from localStorage/sessionStorage
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = async (email: string, role: Role) => {
    // Simulate API call and getting a user object/token
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        const loggedInUser = MOCK_USERS.find(u => u.role === role);
        if (loggedInUser) {
          const userWithEmail: User = {...loggedInUser, email: email};
          setUser(userWithEmail);
          localStorage.setItem('user', JSON.stringify(userWithEmail));
        }
        resolve();
      }, 500);
    });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    // In a real app, you'd also call a logout endpoint
  };
  
  const isAuthenticated = !!user;

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated }}>
      {children}
    </AuthContext.Provider>
  );
};
